import React from 'react';

function App() {
  return (
    <div style={{textAlign: 'center', marginTop: '50px'}}>
      <h1>🚀 React Docker Multi-Stage Build Example</h1>
      <p>Your app is running successfully inside a Docker container!</p>
    </div>
  );
}

export default App;
